
<?php
/*
Plugin Name: My Custom Footer
Plugin URI: http://amarad.sgedu.site        
Description: This plugin will be useful to add the custom footer content.
Author: Amrutha
Version: 1.0
Author URI: 
*/

add_action('admin_menu', 'my_admin_menu');


function my_admin_menu () {
	 add_menu_page('Footer Text title', 'Custom Footer', 'manage_options', 'footer_setting_page', 'mt_settings_page');
} 

function footer_text_admin_page () {
  echo 'the variable is edited here';
} 

function mt_settings_page() {
    echo "<h2>" . __( 'Footer Settings Configurations', 'menu-test' ) . "</h2>";
	include_once('footer_setting.php');
}
?>


<?php
function my_function() {
   echo "<div align='center' style='color: yellowgreen;
    font-size: 18px;
    margin: 20px; '>".get_option('footer_text')."</div>";
}
add_action( 'wp_footer', 'my_function' );
?>